<?php
/**
 * Links Class
 *
 * This helper class allow us to keep our external link references in one place for better control;
 * Links are also filterable;
 * 
 * @since       1.7.0
 * @author      Arindo Duque
 * @category    Admin
 * @package     WP_Ultimo/Links
 * @version     0.0.1
 */

if (!defined('ABSPATH')) {
  exit;
}

class WU_Scripts {

  /**
   * Makes sure we are only using one instance of the class
   *
   * @since 1.8.2
   * @var WU_Scripts
   */
  public static $instance;

  /**
   * Keeps a copy of the plugin version for caching purposes
   *
   * @since 1.8.2
   * @var string
   */
  public $version = '1.0.0';

  /**
   * Returns the instance of WP_Ultimo
   * 
   * @return object A WU_Scripts instance
   */
  public static function get_instance() {

    if (null === self::$instance) self::$instance = new self();

    return self::$instance;

  } // end get_instance;

  /**
   * Initializes the class
   */
  public function __construct() {

    $this->version = WP_Ultimo()->version;

    add_action('admin_enqueue_scripts', array($this, 'register_scripts'), 1);

    add_action('wu_signup_enqueue_scripts', array($this, 'register_scripts'), 1);
    
    add_action('wp_enqueue_scripts', array($this, 'register_scripts'), 1);

    add_action('admin_enqueue_scripts', array($this, 'register_styles'), 1);
    
    add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'), 1);

    add_action('admin_enqueue_scripts', array($this, 'enqueue_styles'), 1);

    add_filter('wu_js_variables', array($this, 'remove_sensitive_info_from_js'), 1);
    
  } // end cosntruct;

  /**
   * Returns the suffix .min if the debugging of scripts is not enabled
   *
   * @since 1.8.2
   * @return string
   */
  public static function suffix() {

    return defined('SCRIPT_DEBUG') && SCRIPT_DEBUG ? '' : '.min';

  } // end if;

  /**
   * We basically send all setting information to the front-end of the admin panel, as it might be useful
   *
   * @since 1.8.2
   * @return array
   */
  public function get_localization_variables() {

    /**
     * Fetch all the plugin settings
     * TODO: We need to change this in the future, as I think this is quite resource intensive for such a simple task
     */
    $plugin_settings = WU_Settings::get_settings();

    /**
     * Aditional settings needed by various parts of the front-end code
     */
    $additional_settings = array(
      'datepicker_locale'    => strtok(get_locale(), '_'),
      'server_clock_start'   => current_time( 'timestamp', true),
      'server_clock_offset'  => (current_time( 'timestamp' ) - current_time( 'timestamp', true )) / 60 / 60,
      'currency_symbol'      => get_wu_currency_symbol($plugin_settings['currency_symbol']),
      'currency_placeholder' => wu_format_currency(0),
    );

    $settings = array_merge($plugin_settings, $additional_settings);

    /**
     * Allow plugin developers to extend the list of variables we send to our JSON variable
     * 
     * @since 1.0.0
     * @param array List of all settings
     */
    return apply_filters('wu_js_variables', $settings);

  } // end get_localization_variables;

  /**
   * Registers the globally necessary scripts
   *
   * @since 1.8.2
   * @return void
   */
  public function register_scripts() {

    $suffix = self::suffix();
    
    /**
     * Register Block UI
     */
    wp_register_script('jquery-blockui', WP_Ultimo()->url('/inc/setup/js/jquery.blockUI.js'), array('jquery'), $this->version);

    /**
     * Register our main script
     */
    wp_register_script('wp-ultimo', WP_Ultimo()->get_asset('scripts.min.js', 'js'), array('jquery', 'backbone', 'masonry', 'jquery-ui-sortable', 'jquery-ui-datepicker'), $this->version, false);

    /**
     * Load variables to localized it
     */
    wp_localize_script('wp-ultimo', 'wpu', $this->get_localization_variables());

    /**
     * Pricing tables
     * @since 1.9.1
     */
     wp_register_script('wu-pricing-table', WP_Ultimo()->get_asset("wu-pricing-table$suffix.js", 'js'), array('jquery'), $this->version, false);

  } // end register_scripts;

  /**
   * Register the globally needed styles
   *
   * @since 1.8.2
   * @return void
   */
  public function register_styles() {

    $suffix = self::suffix();

    /**
     * General WP Ultimo styles
     */
    wp_enqueue_style('wp-ultimo', WP_Ultimo()->get_asset("wp-ultimo$suffix.css", 'css'), array(), $this->version);
    
    /**
     * Additional Styles
     */
    wp_enqueue_style('wp-ultimo-app', WP_Ultimo()->get_asset("app$suffix.css", 'css'), array(), $this->version);

    /**
     * Custom icon font
     */
    wp_enqueue_style('wu-icons', WP_Ultimo()->get_asset("wu-icons$suffix.css", 'css'), array(), $this->version);
    
  } // end register_styles;

  /**
   * Enqueue the globally necessary scripts
   *
   * @since 1.8.2
   * @return void
   */
  public function enqueue_scripts() {

    wp_enqueue_script('wp-ultimo');

  } // end enqueue_scripts;

  /**
   * Enqueue the globally necessary styles
   *
   * @since 1.8.2
   * @return void
   */
  public function enqueue_styles() {

    wp_enqueue_style('wp-ultimo');
    wp_enqueue_style('wp-ultimo-app');
    wp_enqueue_style('wu-icons');

  } // end enqueue_styles;
  
  /**
   * Makes sure we don't leak any sensitive information to the front-end via JS
   *
   * @since 1.3.0
   * @param array $variables
   * @return array
   */
  public function remove_sensitive_info_from_js($variables) {

    $sensitive_information = apply_filters('wu_sensitive_information', array(
      'email_',
      'license_key',
      'paypal',
      'stripe',
      'manual',
      'terms_content',
      'key',
      'api',
      'token',
    ));

    $variables = WU_Util::array_filter_key($variables, function ($key) use ($sensitive_information) {

      foreach($sensitive_information as $sensitive_information) {

        if (stristr($key, $sensitive_information)) {

          return false;

        } // end if;

      } // end foreach;

      return true;

    });

    return $variables;

  } // end extra_js_variables;

} // end class WU_Scripts;

/**
 * Returns the singleton
 */
function WU_Scripts() {

  return WU_Scripts::get_instance();

} // end WU_Scripts;

// Initialize
WU_Scripts();