<?php
/**
 * Pages About
 *
 * Handles the addition of the About Page
 *
 * @author      WPUltimo
 * @category    Admin
 * @package     WPUltimo/Pages
 * @version     0.0.1
*/

if (!defined('ABSPATH')) {
  exit;
}

class WU_Page_About extends WU_Page {
  
  /**
   * Sets the output template for this particular page
   *
   * @since 1.8.2
   * @return void
   */
  public function output() {

    WP_Ultimo()->render('meta/about');

  } // end output;
  
} // end class WU_Page_About;

new WU_Page_About(true, array(
  'id'         => 'wp-ultimo-about',
  'type'       => 'submenu',
  'capability' => 'manage_network',
  'title'      => __('About', 'wp-ultimo'),
  'menu_title' => __('About', 'wp-ultimo'),
));
