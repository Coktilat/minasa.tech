<?php

namespace WU_Stripe\Error;

class Api extends Base
{
}
