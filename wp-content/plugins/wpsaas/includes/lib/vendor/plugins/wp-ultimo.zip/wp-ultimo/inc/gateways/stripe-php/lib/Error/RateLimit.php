<?php

namespace WU_Stripe\Error;

class RateLimit extends InvalidRequest
{
}
