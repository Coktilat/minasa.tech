<?php

namespace WU_Stripe\Error;

class Authentication extends Base
{
}
