<?php

namespace WU_Stripe\Error;

class Permission extends Base
{
}
