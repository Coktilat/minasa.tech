<?php
/**
 * Messages Array
 *
 * @author      WPUltimo
 * @category    Admin
 * @package     WPUltimo/Messages
 * @version     0.0.1
 */

return array(

  /** 
   * Gateway Integration
   */
  
  'integration-removed' => __('Teste', 'wp-ultimo'),


);
