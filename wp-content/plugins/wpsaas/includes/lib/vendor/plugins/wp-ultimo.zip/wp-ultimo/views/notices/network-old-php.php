<div class="error">
  <p><?php printf(__('WP Ultimo requires at least PHP version 5.6 to run. Your current PHP version is <strong>%s</strong>. Please, contact your hosting company support to upgrade your PHP version. If you want maximum performance consider upgrading your PHP to version 7.', 'wp-ultimo'), phpversion()); ?></p>
</div>