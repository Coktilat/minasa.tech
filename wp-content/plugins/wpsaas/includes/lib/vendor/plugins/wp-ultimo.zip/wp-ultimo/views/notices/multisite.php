<div class="error">
  <p><?php printf(__('WP Ultimo requires a multisite install to run properly. To know more about WordPress Networks, visit this link: %s', 'wp-ultimo'), '<a href="http://codex.wordpress.org/Create_A_Network">Create a Network</a>'); ?></p>
</div>