<?php

namespace WU_Stripe;

/**
 * Class BitcoinTransaction
 *
 * @package Stripe
 */
class BitcoinTransaction extends ApiResource
{

}
