<?php

namespace WU_Stripe\Error;

class ApiConnection extends Base
{
}
