<h2><?php echo __('Setup Wizard', 'wp-ultimo') ?></h2>
<p><?php echo __('If you need to access the setup wizard again, please click on the button below.', 'wp-ultimo') ?></p>
<p>
<a href='<?php echo network_admin_url('admin.php?page=wu-setup') ?>' class='button button-primary'><?php echo __('Setup Wizard', 'wp-ultimo') ?></a>
</p>