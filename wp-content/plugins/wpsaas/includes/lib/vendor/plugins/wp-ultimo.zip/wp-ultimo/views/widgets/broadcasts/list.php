<div class="wu-broadcast-table">
<?php

/**
 * Display the table
 * @var WU_Broadcasts_List_Table
 */
$broadcasts_list->display();

?>
</div>